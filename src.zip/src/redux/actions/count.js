import {COUNTER_CHANGE} from '../constants';
import { ADD_USER } from '../constants';

export function changeCount(count) {
   
  return {
    type: COUNTER_CHANGE,
    payload: count,
  };
}

export function addUser(name) {
   
  return {
    type: ADD_USER ,
    name: name,
  };
}
