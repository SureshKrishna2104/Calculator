import { act } from 'react-test-renderer';
import {COUNTER_CHANGE} from '../constants';
import { ADD_USER } from '../constants';
const initialState = {
  count: 0,
  name:[]
};
const countReducer = (state = initialState, action) => {
  switch (action.type) {
    case COUNTER_CHANGE:
      return {
        ...state,
        count: action.payload,
      };
      case ADD_USER:
      
      return {
        ...state,
        name:[...state.name,action.name]
      };
    default:
      return state;
  }
};
export default countReducer;
